#!/bin/bash

ESUDO="sudo"
ESUDOKILL="-sudokill"
if [ -f "/storage/.config/.OS_ARCH" ]; then
  ESUDO=""
  ESUDOKILL="-1" # -1 (numeric one) or "-k" for EmuELEC
fi


if [[ -e "/dev/input/by-path/platform-ff300000.usb-usb-0:1.2:1.0-event-joystick" ]]; then
      param_device="anbernic"
      hotkey="Select"
      DEVICE="03000000091200000031000011010000"
      sdl_controllerconfig="03000000091200000031000011010000,OpenSimHardware OSH PB Controller,a:b0,b:b1,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:h0.4,dpleft:h0.8,dpright:h0.2,dpup:h0.1,leftx:a0~,lefty:a1~,guide:b12,leftstick:b8,lefttrigger:b10,rightstick:b9,back:b7,start:b6,rightx:a2,righty:a3,righttrigger:b11,platform:Linux,"
          sudo rg351p-js2xbox --silent -t oga_joypad &
          sleep 1
          sudo ln -s /dev/input/event3 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
          sleep 1
          sudo chmod 777 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
      if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ] || [ -f "/opt/system/Advanced/Switch to SD2 for Roms.sh" ] || [ -f "/boot/rk3326-rg351v-linux.dtb" ]; then
        param_device="anbernic"
        hotkey="Select"
        DEVICE="03000000091200000031000011010000"
        sdl_controllerconfig="03000000091200000031000011010000,OpenSimHardware OSH PB Controller,a:b0,b:b1,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:h0.4,dpleft:h0.8,dpright:h0.2,dpup:h0.1,leftx:a0~,lefty:a1~,guide:b12,leftstick:b8,lefttrigger:b10,rightstick:b9,back:b7,start:b6,rightx:a2,righty:a3,righttrigger:b11,platform:Linux,"
          sudo rg351p-js2xbox --silent -t oga_joypad &
          sleep 1
          sudo ln -s /dev/input/event3 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
          sleep 1
          sudo chmod 777 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
      fi
elif [[ -e "/dev/input/by-path/platform-odroidgo2-joypad-event-joystick" ]]; then
    if [[ ! -z $(cat /etc/emulationstation/es_input.cfg | grep "190000004b4800000010000001010000") ]]; then
      param_device="oga"
      hotkey="Minus"
      DEVICE="190000004b4800000010000001010000"
      sdl_controllerconfig="190000004b4800000010000001010000,GO-Advance Gamepad (rev 1.1),a:b1,b:b0,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:b9,dpleft:b10,dpright:b11,dpup:b8,leftx:a0,lefty:a1,guide:b12,leftstick:b14,lefttrigger:b13,rightstick:b15,righttrigger:b16,start:b17,platform:Linux,"
          sudo rg351p-js2xbox --silent -t oga_joypad &
          sleep 1
          sudo ln -s /dev/input/event3 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
          sleep 1
          sudo chmod 777 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
	else
      param_device="rk2020"
      hotkey="Select"
      DEVICE="190000004b4800000010000000010000"
      sdl_controllerconfig="190000004b4800000010000000010000,GO-Advance Gamepad,a:b1,b:b0,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:b7,dpleft:b8,dpright:b9,dpup:b6,leftx:a0,lefty:a1,back:b10,lefttrigger:b12,righttrigger:b13,start:b15,platform:Linux,"
          sudo rg351p-js2xbox --silent -t oga_joypad &
          sleep 1
          sudo ln -s /dev/input/event3 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
          sleep 1
          sudo chmod 777 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
   fi
elif [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
      param_device="ogs"
      hotkey="Select"
      DEVICE="190000004b4800000011000000010000"
      sdl_controllerconfig="190000004b4800000011000000010000,GO-Super Gamepad,platform:Linux,x:b2,a:b1,b:b0,y:b3,back:b12,guide:b16,start:b13,dpleft:b10,dpdown:b9,dpright:b11,dpup:b8,leftshoulder:b4,lefttrigger:b6,rightshoulder:b5,righttrigger:b7,leftstick:b14,rightstick:b15,leftx:a0,lefty:a1,rightx:a2,righty:a3,platform:Linux,"
elif [[ -e "/dev/input/by-path/platform-gameforce-gamepad-event-joystick" ]]; then
      param_device="chi"
      hotkey="1"
      DEVICE="19000000030000000300000002030000"
      sdl_controllerconfig="19000000030000000300000002030000,gameforce_gamepad,leftstick:b14,rightx:a3,leftshoulder:b4,start:b9,lefty:a0,dpup:b10,righty:a2,a:b1,b:b0,guide:b16,dpdown:b11,rightshoulder:b5,righttrigger:b7,rightstick:b15,dpright:b13,x:b2,back:b8,leftx:a1,y:b3,dpleft:b12,lefttrigger:b6,platform:Linux,"
          sudo rg351p-js2xbox --silent -t oga_joypad &
          sleep 1
          sudo ln -s /dev/input/event3 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
          sleep 1
          sudo chmod 777 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
elif [[ "$(cat /sys/firmware/devicetree/base/model)" == "Anbernic RG552" ]]; then
      param_device="rg552"
      hotkey="L3"
      DEVICE="190000004b4800000111000000010000"
      sdl_controllerconfig="190000004b4800000111000000010000,retrogame_joypad,a:b1,b:b0,x:b2,y:b3,back:b8,start:b9,rightstick:b12,leftstick:b11,dpleft:b15,dpdown:b14,dpright:b16,dpup:b13,leftshoulder:b4,lefttrigger:b6,rightshoulder:b5,righttrigger:b7,leftx:a0,lefty:a1,rightx:a2,righty:a3,platform:Linux,"
          sudo rg351p-js2xbox --silent -t oga_joypad &
          sleep 1
          sudo ln -s /dev/input/event3 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
          sleep 1
          sudo chmod 777 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
elif [ -e "/dev/input/by-path/platform-singleadc-joypad-event-joystick" ] || [ "$(cat /sys/firmware/devicetree/base/model)" == "Anbernic RG503" ]; then
      param_device="rg503"
      hotkey="Select"
      DEVICE="190000004b4800000111000000010000"
      sdl_controllerconfig="190000004b4800000111000000010000,retrogame_joypad,a:b1,b:b0,x:b2,y:b3,back:b8,start:b9,rightstick:b12,leftstick:b11,dpleft:b15,dpdown:b14,dpright:b16,dpup:b13,leftshoulder:b4,lefttrigger:b6,rightshoulder:b5,righttrigger:b7,leftx:a0,lefty:a1,rightx:a2,righty:a3,platform:Linux,"
          sudo rg351p-js2xbox --silent -t oga_joypad &
          sleep 1
          sudo ln -s /dev/input/event3 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
          sleep 1
          sudo chmod 777 /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
else
      DEVICE="${1}"
      param_device="${2}"
      hotkey="Select"
fi


QLOG_FILE="/home/ark/esupdate.log"

if [ -f "$QLOG_FILE" ]; then
  sudo rm "$QLOG_FILE"
fi

sudo msgbox "This script will repair asound by restoring a backup of ~/.asoundrc and, additionally, /dev/asound.conf.  Type OK in the next screen to proceed."
my_var=`osk "Enter OK here to proceed." | tail -n 1`

echo "$my_var" | tee -a "$QLOG_FILE"

if [[ $my_var = OK ]] || [[ $my_var = ok ]] ; then

UPDATE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

UPDATE_DONE="/home/ark/.config/.repair_asound"

      sudo unzip -X -o $UPDATE_DIR/asoundfix.zip -d /
      sudo chmod 755 /home/ark/.asoundrc
      sudo chmod 755 /home/ark/.asoundrcbak
      sudo chmod 755 /home/ark/.asoundrcbt
      sudo chmod 755 /home/ark/.asoundrcfords
      sudo chmod 755 /home/ark/.asoundrc-hp
      sudo chmod 755 /dev/asound.conf

$ESUDO chmod 666 /dev/tty0
$ESUDO chmod 620 /dev/tty1

# Done applying updates

	sudo touch "$UPDATE_DONE"
	printf "\033c" >> /dev/tty1
	msgbox "A set of the asound configuration has been restored from backup.  If sound issues arise related to asound you can simply run this script again.  The system will restart after pressing the A button.  If it doesn't, it is safe to just restart the system manually from here."
	sudo reboot
	exit 187
	
else
  sudo msgbox "You didn't type OK.  This script will exit now and no changes have been made."
  sudo kill $(pidof rg351p-js2xbox)
  sudo rm /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
  exit 1
fi

if [ $? -ne 187 ]; then
  sudo msgbox "There was an error running this script."
fi

sudo kill $(pidof rg351p-js2xbox)
sudo rm /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
