#!/bin/bash

cd /opt/351Files
./351Files 
