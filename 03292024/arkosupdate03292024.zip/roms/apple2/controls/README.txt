Place a .gptk file in this folder with the same name as your rom/disk image to use a custom controller configuration.

IMPORTANT: The ShamusWorld emulator does NOT work with these controllers so a shamusworld gptk should
           be mapped purely for apple2 keyboard controls.  ShamusWorld doesn't assign auto-caps for letters
           which is necessary for most Apple II titles as well so be sure to add "= add_shift" to the gptk. 
           Apply a game's keyboard movement keys to the left thumbstick in the gptk, for example.

(short example if A on the Apple II keyboard moves up and Z on the Apple II keyboard moves down)
left_analog_up = a
left_analog_up = add_shift
left_analog_down = z
left_analog_down = add_shift


NOTE: These rules only apply to the shamusworld emulator.  The linapple emulator already takes capitailization
      into account and you don't need to (and probably best if you don't) use "= add_shift" for linapple.
      Also, linapple has been slightly reworked to support the controllers.  This is also the reason linapple
      is going to be set as the default emulator.  The ShamusWorld emulator needs work, but it still makes for
      a decent 2nd option in some instances and so has been included.

Even though the ShamusWorld emulator doesn't have the fast loading times like linapple does, it does seem to
handle a small selection of games better such as "Cavern Creatures" and "Archon - The Light and the Dark".
