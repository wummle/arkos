#!/bin/bash

#Copyright 2023 Christian_Haitian
#
#This version re-written/modified in 2024 by Slayer366 (Andrew Kratz) 
#for RG351M and RG351P
#
#The original script by CH that works just fine on the other units did
#NOT work on my RG351P.  For some reason this unit needed some special
#attention.
#
#Permission is hereby granted, free of charge, to any person
#obtaining a copy of this software and associated documentation
#files (the “Software”), to deal in the Software without
#restriction, including without limitation the rights to use,
#copy, modify, merge, publish, distribute, sublicense, and/or
#sell copies of the Software, and to permit persons to whom
#the Software is furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included
#in all copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND,
#EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
#OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
#DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
#OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
#THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# Change SDL for Ports
#

#Uncomment the next line to enable script debugging.
#set -x

ESUDO="sudo"
ESUDOKILL="-sudokill"
if [ -f "/storage/.config/.OS_ARCH" ]; then
  ESUDO=""
  ESUDOKILL="-1" # -1 (numeric one) or "-k" for EmuELEC
fi

$ESUDO chmod 666 /dev/tty0
$ESUDO chmod 666 /dev/tty1
$ESUDO chmod 666 /dev/uinput

if [[ ! -z $(pgrep -f gptokeyb) ]]; then
  pgrep -f gptokeyb | sudo xargs kill -9
fi

export SDL_GAMECONTROLLERCONFIG_FILE="/opt/linapple/gamecontrollerdb.txt"

SCRIPTDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

cd $SCRIPTDIR

#If debugging, uncomment the next line to output everything to a log file.
#> "$SCRIPTDIR/log.txt" && exec > >(tee "$SCRIPTDIR/changesdllog.txt") 2>&1

HEIGHT="15"
WIDTH="55"
CHOICE_HEIGHT="15"

export TERM=linux
export XDG_RUNTIME_DIR=/run/user/$UID/

printf "\033c" > /dev/tty0

/opt/inttools/gptokeyb $ESUDOKILL "dialog" -c "/opt/inttools/keys2.gptk" &
dialog --clear

if [ -f "/home/ark/.config/.DEFAULT_PORTS_SDL" ]; then
   rm -f /home/ark/.config/.DEFAULT_PORTS_SDL
fi

sudo chmod 755 /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.*
sudo chmod 755 /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0.*

#SDL=`grep libSDL2-2.0.so.0. $SDL_SYMLINK | cut -d "." -f5-6 | sed '/00/s///g'`
SDL=`readlink "/usr/lib/aarch64-linux-gnu/libSDL2.so" | grep libSDL2-2.0.so.0. | cut -d "." -f5-6 | sed '/00/s///g'`
SDL="2.$SDL"

printf "\033c" > /dev/tty0
printf "Starting change SDL App.  Please wait..." 2>&1 > /dev/tty0

OPTIONS=(1 "2.10.0"
         2 "2.14.1"
         3 "2.16.0"
         4 "2.18.2 (PM min.)"
         5 "2.26.2"
         6 "2.26.5"
         7 "2.28.2"
         8 "2.30.3"
         9 "2.30.7"
         10 "Exit")

CHOICE=$(dialog --clear \
                --backtitle "SDL: Currently set to $SDL" \
                --title "Main Menu" \
                --cancel-label "Select + Start to Exit" \
                --menu "            Please make your selection\n     PortMaster requires SDL2 2.18.2 or newer" \
                $HEIGHT $WIDTH $CHOICE_HEIGHT \
                "${OPTIONS[@]}" \
                2>&1 >/dev/tty0 )

clear
case $CHOICE in
        1)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "Link libSDL2-2.0.so.0.10.0" > /dev/tty0
            echo " " > /dev/tty0
            #echo "/usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.10.0" > /home/ark/.config/.DEFAULT_PORTS_SDL
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2.so /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0 /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.10.0 /usr/lib/aarch64-linux-gnu/libSDL2.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2.so /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0 /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0.10.0 /usr/lib/arm-linux-gnueabihf/libSDL2.so
            sleep 2
            $ESUDO kill -9 $(pidof gptokeyb)
            ;;
        2)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "Link libSDL2-2.0.so.0.14.1" > /dev/tty0
            echo " " > /dev/tty0
            #echo "/usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.14.1" > /home/ark/.config/.DEFAULT_PORTS_SDL
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2.so /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0 /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.14.1 /usr/lib/aarch64-linux-gnu/libSDL2.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2.so /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0 /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0.10.0 /usr/lib/arm-linux-gnueabihf/libSDL2.so
            sleep 2
            $ESUDO kill -9 $(pidof gptokeyb)
            ;;
        3)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "Link libSDL2-2.0.so.0.16.0" > /dev/tty0
            echo " " > /dev/tty0
            #echo "/usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.16.0" > /home/ark/.config/.DEFAULT_PORTS_SDL
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2.so /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0 /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.16.0 /usr/lib/aarch64-linux-gnu/libSDL2.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2.so /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0 /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0.10.0 /usr/lib/arm-linux-gnueabihf/libSDL2.so
            sleep 2
            $ESUDO kill -9 $(pidof gptokeyb)
            ;;
        4)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "Link libSDL2-2.0.so.0.18.2" > /dev/tty0
            echo " " > /dev/tty0
            #echo "/usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.18.2" > /home/ark/.config/.DEFAULT_PORTS_SDL
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2.so /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0 /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.18.2 /usr/lib/aarch64-linux-gnu/libSDL2.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2.so /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0 /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0.18.2 /usr/lib/arm-linux-gnueabihf/libSDL2.so
            sleep 2
            $ESUDO kill -9 $(pidof gptokeyb)
            ;;
        5)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "Link libSDL2-2.0.so.0.2600.2" > /dev/tty0
            echo " " > /dev/tty0
            #echo "/usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.2600.2" > /home/ark/.config/.DEFAULT_PORTS_SDL
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2.so /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0 /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.2600.2 /usr/lib/aarch64-linux-gnu/libSDL2.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2.so /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0 /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0.2600.2 /usr/lib/arm-linux-gnueabihf/libSDL2.so
            sleep 2
            $ESUDO kill -9 $(pidof gptokeyb)
            ;;
        6)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "Link libSDL2-2.0.so.0.2600.5" > /dev/tty0
            echo " " > /dev/tty0
            #echo "/usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.2600.5" > /home/ark/.config/.DEFAULT_PORTS_SDL
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2.so /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0 /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.2600.5 /usr/lib/aarch64-linux-gnu/libSDL2.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2.so /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0 /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0.2600.2 /usr/lib/arm-linux-gnueabihf/libSDL2.so
            sleep 2
            $ESUDO kill -9 $(pidof gptokeyb)
            ;;
        7)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "Link libSDL2-2.0.so.0.2800.2" > /dev/tty0
            echo " " > /dev/tty0
            #echo "/usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.2800.2" > /home/ark/.config/.DEFAULT_PORTS_SDL
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2.so /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0 /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.2800.2 /usr/lib/aarch64-linux-gnu/libSDL2.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2.so /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0 /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0.2800.2 /usr/lib/arm-linux-gnueabihf/libSDL2.so
            sleep 2
            $ESUDO kill -9 $(pidof gptokeyb)
            ;;
        8)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "Link libSDL2-2.0.so.0.3000.3" > /dev/tty0
            echo " " > /dev/tty0
            #echo "/usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.3000.3" > /home/ark/.config/.DEFAULT_PORTS_SDL
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2.so /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0 /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.3000.3 /usr/lib/aarch64-linux-gnu/libSDL2.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2.so /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0 /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0.3000.3 /usr/lib/arm-linux-gnueabihf/libSDL2.so
            sleep 2
            $ESUDO kill -9 $(pidof gptokeyb)
            ;;
        9)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "Link libSDL2-2.0.so.0.3000.7" > /dev/tty0
            echo " " > /dev/tty0
            #echo "/usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.3000.7" > /home/ark/.config/.DEFAULT_PORTS_SDL
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2.so /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0 /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/aarch64-linux-gnu/libSDL2-2.0.so.0.3000.7 /usr/lib/aarch64-linux-gnu/libSDL2.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2.so /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0 /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so
            sudo ln -sfv /usr/lib/arm-linux-gnueabihf/libSDL2-2.0.so.0.3000.7 /usr/lib/arm-linux-gnueabihf/libSDL2.so
            sleep 2
            $ESUDO kill -9 $(pidof gptokeyb)
            ;;
        10)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "Exiting" > /dev/tty0
            echo " " > /dev/tty0
            sleep 1
            $ESUDO kill -9 $(pidof dialog)
            $ESUDO kill -9 $(pidof gptokeyb)
            ;;

esac

if [[ ! -z $(pgrep -f gptokeyb) ]]; then
  pgrep -f gptokeyb | sudo xargs kill -9
fi
printf "\033c" > /dev/tty0
printf "\033c" > /dev/tty1
