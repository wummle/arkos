These configuration files work only with linapple and do not have any effect with the shamusworld emulator.
Place a .conf file in this folder with the same name as your rom/disk image to use a custom linapple configuration.
If using the Mockingboard or its speech, be sure to disable the ProDOS Clock card (set it to 0) as it will conflict.