There is also support for .apple2 files (similar to how Doom can use .doom files)!
Create a file ending with .apple2 or .APPLE2.  If using Windows to make one, make sure the line endings get set to LF.

This comes in particularly handy when dealing with two-sided disk games.
A custom conf file for linapple is entirely optional.
IMPORTANT: You will need a custom gptk file inside the 'controls' folder with the same name as your apple2 file.
Don't forget to map 'f5' to one of the buttons in your gptk file so you can *flip the disk over*.

The following legend displays the possible entries that can be used in your apple2 file:
DISK1=
DISK2=
HDD1=
HDD2=
CONF=
-- end --

IMPORTANT: If you decide not to use a variable, do not enter the variable without an entry like shown above.
           Doing so will confuse the system and will fail to launch.  If you wish to enter one disk and
           nothing else, this what should be entered into your .apple2 file:
DISK1=mydisk.dsk
-- end --

An example with three variables filled (e.g.):
DISK1=diskside1.dsk
DISK2=diskside2.dsk
CONF=custom_linapple.conf
-- end --

An example with just a hard disk (e.g.):
HDD1=firstharddisk.hdv
-- end --


NOTE: While the .apple2 files will "work" with the shamusworld emulator, it won't 
      be very fruitful as shamusworld will only accept the DISK1 entry due to its 
      lack of command line options.  This may change in the future if shamusworld
      receives updates.

      While unrelated to the apple2 files, in the shamusworld emulator you can, however,
      use the mouse with the right thumbstick to bring up the side menu where you can click 
      on the second floppy drive and use that menu to insert a second disk!

While the shamusworld emulator has some really neat features, it isn't quite as polished or as stable as linapple.
Additionally, linapple supports loading images from zip archives, but shamusworld does not.
