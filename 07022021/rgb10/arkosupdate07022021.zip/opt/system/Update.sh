#!/bin/bash

LOG_FILE="/home/ark/esupdate.log"

if [ -f "$LOG_FILE" ]; then
  sudo rm "$LOG_FILE"
fi

wget https://github.com/christianhaitian/arkos/raw/main/Update-RGB10.sh -O /home/ark/ArkOSUpdate.sh -a "$LOG_FILE"
sudo chmod -v 777 /home/ark/ArkOSUpdate.sh | tee -a "$LOG_FILE"
sh /home/ark/ArkOSUpdate.sh

if [ $? -ne 187 ]; then
  sudo msgbox "There was an error with attempting this update."
  printf "There was an error with attempting this update." | tee -a "$LOG_FILE"
fi
