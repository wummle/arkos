These configuration files work only with linapple and do not have any effect with the shamusworld emulator.
Place a .conf file in this folder with the same name as your rom/disk image to use a custom linapple configuration.
