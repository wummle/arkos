There is also support for .apple2 files (similar to how Doom can use .doom files)!
Create a file ending with .apple2 or .APPLE2.  If using Windows to make one, make sure the line endings get set to LF.

This comes in particularly handy when dealing with two-sided disk games.
A custom conf file for linapple is entirely optional.
IMPORTANT: You will need a custom gptk file inside the 'controls' folder with the same name as your apple2 file.
Don't forget to map 'f5' to one of the buttons in your gptk file so you can *flip the disk over*.

The following legend displays the possible entries that can be used in your apple2 file:
DISK1=
DISK2=
HDD=
CONF=
-- end --

IMPORTANT: If you decide not to use a variable, do not enter the variable without an entry like shown above.
           Doing so will confuse the system and will fail to launch.  If you wish to enter one disk and
           nothing else, this what should be entered into your .apple2 file:
DISK1=mydisk.dsk
-- end --

An example with all three variables filled (e.g.):
DISK1=diskside1.dsk
DISK2=diskside2.dsk
HDD=totalreplay.hdv
CONF=custom_linapple.conf
-- end --

HDD NOTE: The HDD entry above will only work with the applewin emulator, however, you can create a custom
          linapple.conf file, enable the HDD and point to a hdv file and then use the CONF entry to load
          a Hard Disk image with linapple alternatively.

NOTE: While the .apple2 files will "work" with the shamusworld emulator, it won't 
      be very fruitful as shamusworld will only accept the DISK1 entry due to its 
      lack of command line options.  

      While unrelated to the apple2 files, in the shamusworld emulator you can, however,
      use the mouse with the right thumbstick to bring up the side menu where you can click 
      on the second floppy drive and use that menu to insert a second disk!

While the shamusworld emulator has some neat features, it isn't quite as polished or as stable as linapple or applewin.
Shamusworld also seems to lack the ability to load disk images from zip archives.
