// TC: Created for compatibility for VS Express

#include "winresrc.h"
#define IDC_STATIC (-1)
